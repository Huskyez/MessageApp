#ifndef _COMMUNICATION_TYPES_H_
#define _COMMUNICATION_TYPES_H_

typedef unsigned char CM_BYTE;
typedef unsigned __int32 CM_SIZE;

#endif // !_COMMUNICATION_TYPES_H_
